# app/main.py
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from app.security.user_ip_log.middleware import AccessLogMiddleware
import logging, re
from urllib.parse import urlparse
import os
from app.database import init_db
from app.problem.services.bookmark_flush_redis import bookmark_flush_loop
import asyncio
from app.logging.admin_log_handler import setup_admin_log_forwarding, start_health_ping_loop
# ── 라우터 ──────────────────────────────────────────────
from app.user.routers import user
from app.group.routers import group, group_request, group_member
from app.workbook.routers import workbook
from app.problem.routers import problem
from app.problem_ref.routers import problem_ref
from app.inputdata.routers import inputdata
from app.inputdata.intake.router import router as intake_router
from app.submission.routers import submission
from app.comment.routers import comment
from app.code_logs.routers import code_logs
from app.live.router.live import router as live_router
from app.chatting.router import chatting
from app.hallym_sso.routes import router as hallym_sso_router
from app.note.routers.note import router as note_router
from app.user_session.router.presence import router as ws_presence_router
from app.submission.routers.graph import router as graph_router
from app.image_storage.routers.storage import router as storage_router
from app.group.routers.group_roster import router as group_roster_router
from app.ws.router import router as ws_message_router
from app.solo_submission.routers import solo_submission
from app.group.routers.sticky_note import router as sticky_note_router
from app.workbook_class_week.routers import class_week
from app.workbook_class_week.models.class_week import ClassWeek
from app.live.router.admin_status import router as admin_status_router
from app.inquiry.routers.inquiry import router as inquiry_router
from app.inquiry.routers.admin_inquiry import (
    router as admin_inquiry_router,
    manager_router as inquiry_manager_router,
    api_key_router as inquiry_api_key_router,
)
from app.inquiry.routers.center_inquiry import router as center_inquiry_router
from app.monitoring.routers.status import router as status_router

app = FastAPI()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    
)

logger = logging.getLogger(__name__)

# ── 관리자 로그 전송 설정 ───────────────────────────────
setup_admin_log_forwarding()

# ── Origin 정규화 유틸 ─────────────────────────────────
def _norm_origin(origin: str) -> str:
    """scheme://host[:port] 형식으로 정규화"""
    if not origin: 
        return ""
    o = urlparse(origin.strip())
    return f"{o.scheme.lower()}://{o.netloc.lower()}".rstrip("/")

def _host_only(origin_or_host: str) -> str:
    """호스트만 추출 (스킴 무시 비교용)"""
    if not origin_or_host:
        return ""
    if "://" in origin_or_host:
        o = urlparse(origin_or_host.strip())
        return o.netloc.lower()
    return origin_or_host.strip().lower()

def _forwarded_base(request: Request) -> tuple[str, str, str]:
    """
    프록시 환경 고려한 base 산출:
    - proto: X-Forwarded-Proto → 없으면 request.url.scheme
    - host:  X-Forwarded-Host → 없으면 Host
    - base:  f"{proto}://{host}"
    """
    headers = request.headers
    proto = (headers.get("x-forwarded-proto") or request.url.scheme or "http").lower()
    host  = (headers.get("x-forwarded-host") or headers.get("host") or "").lower()
    base  = f"{proto}://{host}".rstrip("/") if host else ""
    return proto, host, base

# ── 허용 오리진 정의 (CORS와 미들웨어 공통 사용) ─────────
ALLOWED_ORIGINS_RAW = [
    "http://localhost:3000",
    "https://aprofi-test.vercel.app",
    "https://aprofi.vercel.app",
    "https://hellonoti.com",
    "https://api.hellonoti.co.kr",      # ★ 추가
    "https://hellonoti.co.kr",          # ★ 추가(루트 도메인도 쓰면)
    "https://notiworld.cloud",
    "https://www.notiworld.cloud",             # ★ 추가
    "https://haicoder.k-university.ai",
    "https://www.haicoder.k-university.ai",    # ★ 필요시 (www 붙는 경우 대비)
]
ALLOWED_ORIGINS = {_norm_origin(o) for o in ALLOWED_ORIGINS_RAW}
ALLOWED_HOSTS   = {_host_only(o)   for o in ALLOWED_ORIGINS_RAW}  # 스킴 무시 비교

# ── CORS ────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=list(ALLOWED_ORIGINS),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["x-access-token"],
)

# ── startup: DB 초기화(배치/스케줄러는 별도 컨테이너) ──────
@app.on_event("startup")
async def startup():
    await init_db()
    from app.chatting.service.message_file_service import ensure_message_files_bucket
    ensure_message_files_bucket()
    from app.image_storage.storage import ensure_bucket
    ensure_bucket()
    asyncio.create_task(bookmark_flush_loop())
    asyncio.create_task(start_health_ping_loop())

# ── 헬스엔드포인트 ─────────────────────────────────────
@app.get("/health")
async def health():
    return {"ok": True}

@app.get("/")
async def root():
    return {"root": 200}

# ── 회원가입 경로만 엄격검사하는 미들웨어 ────────────────
ENFORCE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
SAFE_PATHS = {"/", "/health", "/docs", "/openapi.json", "/redoc"}
SIGNUP_PATTERNS = [
    re.compile(r"^/api/user/(signup|sign-up|register|registration|create)$"),
    re.compile(r"^/api/sso/(signup|register|create)$"),
]
def _is_signup_path(path: str) -> bool:
    return any(pat.match(path) for pat in SIGNUP_PATTERNS)

@app.middleware("http")
async def enforce_browser_origin_on_signup(request: Request, call_next):
    if request.method.upper() == "OPTIONS":
        return await call_next(request)

    path   = request.url.path
    method = request.method.upper()
    origin_raw = request.headers.get("origin") or ""
    origin = _norm_origin(origin_raw)
    _, fwd_host, fwd_base = _forwarded_base(request)

    logging.debug(f"[ORIGINCHK] path={path} method={method} origin={origin} "
                 f"fwd_base={fwd_base} fwd_host={fwd_host} "
                 f"allowed_hosts={ALLOWED_HOSTS}")

    if path in SAFE_PATHS:
        return await call_next(request)

    if _is_signup_path(path) and method in ENFORCE_METHODS:
        if origin:
            if origin in ALLOWED_ORIGINS or _host_only(origin) in ALLOWED_HOSTS:
                return await call_next(request)
            return JSONResponse(
                status_code=403,
                content={"detail": "Forbidden origin"},
            )
        else:
            if (fwd_base in ALLOWED_ORIGINS) or (fwd_host in ALLOWED_HOSTS):
                return await call_next(request)
            return JSONResponse(
                status_code=403,
                content={"detail": "Forbidden origin (no Origin)"},
            )

    return await call_next(request)

# ── 라우터 등록 ─────────────────────────────────────────
app.include_router(user.router,          prefix="/api", tags=["user"])
app.include_router(group.router,         prefix="/api", tags=["group"])
app.include_router(group_request.router, prefix="/api", tags=["group_request"])
app.include_router(group_member.router,  prefix="/api", tags=["group_member"])
app.include_router(workbook.router,      prefix="/api", tags=["workbook"])
app.include_router(problem.router,       prefix="/api", tags=["problem"])
app.include_router(problem_ref.router,   prefix="/api", tags=["problem_ref"])
app.include_router(inputdata.router,     prefix="/api", tags=["inputdata"])
app.include_router(intake_router,        prefix="/api", tags=["inputdata_intake"])
app.include_router(submission.router,    prefix="/api", tags=["submission"])
app.include_router(comment.router,       prefix="/api", tags=["comment"])
app.include_router(code_logs.router,     prefix="/api", tags=["code_logs"])
app.include_router(live_router,          prefix="/api")
app.include_router(hallym_sso_router)
app.include_router(chatting.router,      prefix="/api", tags=["chatting"])
app.include_router(ws_presence_router)
app.include_router(ws_message_router)
app.include_router(graph_router,        prefix="/api", tags=["graphs"])
app.include_router(storage_router,     prefix="/api", tags=["storage"])
app.include_router(note_router,        prefix="/api", tags=["note"])
app.include_router(group_roster_router, prefix="/api", tags=["group_roster"])
app.include_router(solo_submission.router, prefix="/api", tags=["solo_submission"])
app.include_router(sticky_note_router,  prefix="/api")
app.include_router(class_week.router, prefix="/api", tags=["workbook_class_week"])
app.include_router(admin_status_router)
app.include_router(inquiry_router,      prefix="/api", tags=["inquiry"])
app.include_router(admin_inquiry_router,  prefix="/api", tags=["inquiry_admin"])
app.include_router(inquiry_manager_router, prefix="/api", tags=["inquiry_admin"])
app.include_router(inquiry_api_key_router, prefix="/api", tags=["inquiry_admin"])
# 센터(OmniData) 전용 — X-API-Key/IP 인증, 운영 Swagger에 절대 노출 금지
app.include_router(center_inquiry_router, prefix="/api", tags=["inquiry_center"], include_in_schema=False)
app.include_router(status_router,       prefix="/api", tags=["status"])

#-- ip관련 보안 ----------------------------------------------
app.add_middleware(AccessLogMiddleware)


# ── 로깅 ────────────────────────────────────────────────
sql_log_level = logging.DEBUG if os.getenv("SQL_LOG", "false") == "true" else logging.WARNING
logging.getLogger("sqlalchemy.engine").setLevel(sql_log_level)
logging.getLogger("sqlalchemy.pool").setLevel(sql_log_level)
